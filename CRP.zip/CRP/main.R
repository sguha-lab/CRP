

smoothIndx = ALLstudy$type == "smooth"
data <- NULL

data$X = ALLstudy$Xstar[,smoothIndx]
data$varNames = dimnames(data$X)[[2]]
data$X = matrix(unlist(data$X), nrow=n)

data$n = nrow(data$X)
data_test$n = n.test
data$p = data_test$p = ncol(data$X)
data$M = data_test$M = 1
data$b1 = data_test$b1 = 10

true_parm =  NULL

row.frac.probes=.1
col.frac.probes=.1
shuffle.indx.prob = .5

c(All.Stuff0, All.Stuff1, All.Stuff) %<-% fn.mcmc(true_parm, data,n.burn,n.reps, row.frac.probes, col.frac.probes, shuffle.indx.prob)



