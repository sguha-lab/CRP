
fn.taxicab <- function(parm, true_parm)
{
  tmp.mat <- array(0,c(parm$p,parm$p))
  
  for (jj in 1:parm$G.max)
  {indx.jj <- which(parm$clust$c.v==jj)
  tmp.mat[indx.jj,indx.jj] <- 1
  }
  
  mean.col.taxicab <- mean(true_parm$clust$col.nbhd.matrix != tmp.mat)
  
  ##
  tmp.mat <- array(0,c(parm$n,parm$n))
  
  for (jj in 1:parm$K.max)
  {indx.jj <- which(parm$clust$s.v==jj)
  tmp.mat[indx.jj,indx.jj] <- 1
  }
  
  mean.row.taxicab <- mean(true_parm$clust$row.nbhd.matrix != tmp.mat)
  
  c(mean.col.taxicab, mean.row.taxicab)
}



fn.Dist <- function(parm)
{
  
  tmp.mat <- array(,c(parm$p,parm$p))
  
  for (gg in 1:parm$G.max)
    {I.gg <- parm$colClustMembers[[gg]]
    flag.gg = length(I.gg) > 0
    
    
    if (flag.gg)
      {tmp.mat[I.gg,I.gg] <- 0
      
      if (gg == parm$G.max)
        next
      
      for (gg2 in (gg+1):parm$G.max)
        {I.gg2 <- parm$colClustMembers[[gg2]]
        flag.gg2 = length(I.gg2) > 0
        
        if (flag.gg2)
          {tmp.mat[I.gg,I.gg2] = mean((parm$clust$phi.mt[,gg]-parm$clust$phi.mt[,gg2])^2)
          tmp.mat[I.gg2,I.gg] = tmp.mat[I.gg,I.gg2] 
          }
        } 
      } 
    
    } 
  
  parm$clust$colDist.mt = tmp.mat
  
  tmp.mat <- array(,c(parm$n,parm$n))
  
  for (ss in 1:parm$K.max)
  {I.ss <- parm$rowClustMembers[[ss]]
  flag.ss = length(I.ss) > 0
  
  if (flag.ss)
    {tmp.mat[I.ss,I.ss] <- 0
    
    if (ss == parm$K.max)
      next
    
    for (ss2 in (ss+1):parm$K.max)
      {I.ss2 <- parm$rowClustMembers[[ss2]]
      flag.ss2 = length(I.ss2) > 0
      
      if (flag.ss2)
        {tmp.mat[I.ss,I.ss2] = mean((parm$clust$phi.mt[ss,]-parm$clust$phi.mt[ss2,])^2)
        tmp.mat[I.ss2,I.ss] = tmp.mat[I.ss,I.ss2] 
        }
      } 
    } 
  
  } 
  
  parm$clust$rowDist.mt = tmp.mat
  
  parm
}


fn.indexes <- function(parm, rowFlag)
{
  if (!rowFlag)
    {
    parm$colClustMembers = rep(list(NA),parm$G.max)
    
    for (gg in 1:parm$G.max)
      {I.gg <- which(parm$clust$c.v==gg)
      parm$colClustMembers[[gg]] = I.gg
      }
    }

  if (rowFlag)
  {
    parm$rowClustMembers = rep(list(NA),parm$K.max)
    
    for (ss in 1:parm$K.max)
      {I.ss <- which(parm$clust$s.v==ss)
      parm$rowClustMembers[[ss]] = I.ss
      }
  }
  
  parm  
}


fn.clusterSummariesSmooth <- function(parm, initFlag=FALSE, updateRows=TRUE, updateCols=TRUE)
{
  
  parm$clust$cellCounts.mt <- array(0,c(parm$K.max,parm$G.max))
  parm$clust$cellMeans.mt <- parm$clust$cellSS.mt <- array(0,c(parm$K.max,parm$G.max))
  
  if (initFlag)
    {parm$clust$phi.mt = array(,c(parm$K.max,parm$G.max))
    }
  if (updateCols)
    {parm = fn.indexes(parm, rowFlag=FALSE)
    }
  if (updateRows)
    {parm = fn.indexes(parm, rowFlag=TRUE)
    }
  
  for (gg in 1:parm$G.max)
    {
    I.gg <- parm$colClustMembers[[gg]]
    flag.gg = length(I.gg) > 0
    
    if (!flag.gg)
      {parm$clust$cellCounts.mt[,gg] <- 0
      parm$clust$cellMeans.mt[,gg] <- 0
      parm$clust$cellSS.mt[,gg] <- 0
      }
    
    if (flag.gg)
      {
        for (ss in 1:parm$K.max)
          {
          I.ss <- parm$rowClustMembers[[ss]]
          if (length(I.ss) > 0)
            {
              parm$clust$cellCounts.mt[ss,gg] <- length(I.gg)*length(I.ss)
              
              if (parm$clust$cellCounts.mt[ss,gg]>0)
                {X_sg = parm$X[I.ss,I.gg]
                parm$clust$cellMeans.mt[ss,gg] <- mean(X_sg)
                
                if (initFlag)
                  {parm$clust$phi.mt[ss,gg] = parm$clust$cellMeans.mt[ss,gg]
                  }
                parm$clust$cellSS.mt[ss,gg] <- sum((X_sg - parm$clust$phi.mt[ss,gg])^2)
                } 
              
            } 
          } 
      } 
    } 
  
  parm$clust$n.vec = rowSums(parm$clust$cellCounts.mt)/parm$p
  parm$clust$C.m.vec = colSums(parm$clust$cellCounts.mt)/parm$n
  
  parm
}


fn.init.clusters <- function(parm)
{
	X.mt <- parm$X

	options(warn=0)
	tmp2 <- kmeans(t(X.mt), iter.max=1000, centers=parm$G.max, nstart=2)
	options(warn=2)
	#
	parm$clust$c.v <- tmp2$cluster

	options(warn=0)
	tmp2 <- kmeans(X.mt, iter.max=1000, centers=parm$K.max, nstart=2)
	options(warn=2)
	
	parm$clust$s.v <- tmp2$cluster
	
  parm = fn.clusterSummariesSmooth(parm, initFlag = TRUE)
	
	parm$d <- 0


	parm
}


fn.eda <- function(parm)
{

	parm <- fn.init.clusters(parm)
	
	parm = fn.clusterSummariesSmooth(parm, initFlag = TRUE)
	
	parm$clust$phi.mt <- parm$clust$cellMeans.mt

	parm$tau = sqrt(sum(parm$clust$cellSS.mt)/data$n/data$p)

	parm

	}



fn.init <- function(data)
	{

	parm <- NULL
	
	parm$K.max <- round(data$n/10)
	parm$G.max <- round(data$p/4) 
	
	parm$n <- data$n 
	parm$p <- data$p  
	
	parm$M <- data$M

	parm$b1 <- data$b1
	
	parm <- fn.eda(parm)

	parm <- fn.assign.priors(parm)
	
	parm <- fn.hyperParameters(parm)
	
	parm$colUpdateIndx = 1:parm$p
	parm$rowUpdateIndx = 1:parm$n

	parm

	}


fn.assign.priors <- function(parm)
	{

	parm$prior$tau <- NULL
	parm$prior$tau$alpha.tau <- 1e-2
	parm$prior$tau$beta.tau <- 1e-2

	parm$prior$tau$max <- sqrt(.75)*sd(as.vector(parm$X), na.rm=TRUE)
	parm$prior$tau$min <- 1e-10
	parm$prior$tau.sq$max <- parm$prior$tau$max^2
	parm$prior$tau.sq$min <- parm$prior$tau$min^2
	parm$prior$inv.tau.sq$max <- 1/parm$prior$tau.sq$min
	parm$prior$inv.tau.sq$min <- 1/parm$prior$tau.sq$max
	
	parm$clust$mu2 <- mean(as.vector(parm$clust$phi.mt))
	parm$clust$tau2 <- sd(as.vector(parm$clust$phi.mt))
	
	parm
}


fn.hyperParameters  <- function(parm)
	{
  
  parm = fn.clusterSummariesSmooth(parm, updateRows=FALSE, updateCols=FALSE)
  
  shape1 = parm$prior$tau$alpha.tau + parm$n*parm$p
  rate1 = parm$prior$tau$beta.tau + sum(parm$clust$cellSS.mt)
  
  parm$tau = 1/sqrt(rgamma(n=1, shape = shape1, rate=rate1)) 
  
  parm$clust$postPrec.mt <- parm$clust$cellCounts.mt/parm$tau^2 + 1/parm$clust$tau2^2 
  
  parm$clust$postSD.mt <- sqrt(1/parm$clust$postPrec.mt)
  parm$clust$postMeans.mt <- parm$clust$cellCounts.mt/parm$tau^2*parm$clust$cellMeans.mt + 1/parm$clust$tau2^2*parm$clust$mu2
  parm$clust$postMeans.mt <- parm$clust$postMeans.mt/parm$clust$postPrec.mt
  
  
  for (gg in 1:parm$G.max)
    for (ss in 1:parm$K.max)
    {parm$clust$phi.mt[ss,gg] = rnorm(n=1,parm$clust$postMeans.mt[ss,gg],parm$clust$postSD.mt[ss,gg])
    }
 
  parm = fn.clusterSummariesSmooth(parm, updateRows=FALSE, updateCols=FALSE)
  
  parm
}



########################################

fn.iter <- function(data, parm, row.frac.probes, col.frac.probes, postLSAFlag=FALSE)
	{
  parm <- fn.hyperParameters(parm)
  
  if (!postLSAFlag)
  {
    parm = fn.row.gibbs(parm)
    parm = fn.column.gibbs(parm)
  }
  
	parm


	}


fn.entropy <- function(parm, rowFlag, frac.probes)
{
  parm = fn.clusterPostProb(parm, rowFlag)
  logEntropy.v = log(apply(parm$clust$post.prob.mt,1,entropy))
  
  miniFlag = length(which(is.finite(logEntropy.v)))>0
  NP = nrow(parm$clust$post.prob.mt)
  
  if (miniFlag)
  {
    cutoff = quantile(logEntropy.v, (1-frac.probes))
    
    if (is.finite(cutoff))
      {Indx = which(logEntropy.v>cutoff)
      }
    
    if (!is.finite(cutoff))
      {Indx = which(is.finite(logEntropy.v))
      
      if (length(Indx) < NP)
        {remainIndx = setdiff(1:NP,Indx)
        moreIndx = sample(remainIndx,size=(NP-length(Indx)))
        }
      Indx = c(Indx, moreIndx)
      }
  }
  
  if (!miniFlag)
  { 
    Indx = sample(1:NP,size=round(frac.probes*NP))
  }
  
  Indx
}


fn.subset <- function(parm, row.frac.probes, col.frac.probes, entropy.prob)
{
  parm$colUpdateIndx = 1:parm$p
  parm$rowUpdateIndx = 1:parm$n
  
  useEntropy = as.logical(rbinom(n=1,size=1,entropy.prob))
  
  if (useEntropy)
  {
    parm$colUpdateIndx = fn.entropy(parm, rowFlag=FALSE, col.frac.probes)
    parm$rowUpdateIndx  = fn.entropy(parm, rowFlag=TRUE, row.frac.probes)
  }
  
  if (!useEntropy)
  {
    parm$colUpdateIndx = sample(1:parm$p, replace=FALSE, size=round(col.frac.probes*parm$p))
    parm$rowUpdateIndx  = sample(1:parm$n, replace=FALSE, size=round(row.frac.probes*parm$n))
  }
  
  parm
}

fn.test.colMissing = function(data_test, test.miss.prob)
{ data_test_missing = data_test
  
  for (i in 1:nrow(data_test_missing$X))
    {indx.i = as.logical(rbinom(n=data_test$p, size=1,prob=test.miss.prob))
    
    data_test_missing$X[i,indx.i]=NA
    }
  
  data_test_missing
}
  
#############################################

fn.workSmooth <- function(tcgaFlag, storeFlag, LSAFlag, postLSAFlag, text, text2, n.iter, parm2=parm, true_parm2=true_parm, row.frac.probes2=row.frac.probes, col.frac.probes2=col.frac.probes, shuffle.indx.prob2=shuffle.indx.prob, entropy.prob2=entropy.prob, meanRowFuzzy.mt=NULL, meanColFuzzy.mt=NULL)
{
  init.parm2 = parm2
  
  if (storeFlag)
    {Stuff <- NULL
    #
    Stuff$tau.v <- Stuff$G.v <- Stuff$K.v <- array(,n.iter)
    Stuff$mean.parity.v  <- Stuff$mean.col.taxicab.v  <- Stuff$mean.row.taxicab.v  <- array(,n.iter)
    Stuff$rowFuzzy.mt  <- array(0,c(parm2$n,parm2$n))
    Stuff$colFuzzy.mt  <- array(0,c(parm2$p,parm2$p))
    
    Stuff$fuzzyDiff.v = array(,n.iter)
    }
  
  if (postLSAFlag)
    {Stuff <- NULL
    #
    Stuff$phi.mt = array(0,dim(parm2$clust$phi.mt))
    }
  
  for (cc in 1:n.iter)
    {if (as.logical(rbinom(n=1,size=1,shuffle.indx.prob2)))
      {parm2 = fn.subset(parm2, row.frac.probes2, col.frac.probes2, entropy.prob2)
      }
    
    parm2 <- fn.iter(data, parm2, row.frac.probes2, col.frac.probes2, postLSAFlag)
    
    if (storeFlag)
      {Stuff$G.v[cc] <- sum(parm2$clust$C.m.vec>0)
      Stuff$K.v[cc] <- sum(parm2$clust$n.vec>0)
      Stuff$tau.v[cc] <- parm2$tau
      

      parm2 = fn.Dist(parm2)
      

      if (LSAFlag)
        {minn = Inf
        Stuff$fuzzyDiff.v[cc] = mean(parm2$clust$rowDist.mt-meanRowFuzzy.mt)^2 + mean(parm2$clust$colDist.mt-meanColFuzzy.mt)^2
        
        if (Stuff$fuzzyDiff.v[cc] < minn)
          {Stuff$LSA_parm = parm2
          minn = Stuff$fuzzyDiff.v[cc]
          }
        } 
      
      } 
    
    if (postLSAFlag)
      {Stuff$phi.mt = Stuff$phi.mt + parm2$clust$phi.mt
      }
    
  } 
  
  if (storeFlag)
    {Stuff$rowFuzzy.mt  <- Stuff$rowFuzzy.mt/n.iter
    Stuff$colFuzzy.mt  <- Stuff$colFuzzy.mt/n.iter
    
    Stuff$parm <- parm2
    Stuff$init.parm <- init.parm2
    
    return(Stuff)
    }
  
  if ((!storeFlag)&(!postLSAFlag))
    {return(parm2)
    }
  
  if (postLSAFlag)
    {
      Stuff$parm <- parm2
      Stuff$init.parm <- init.parm2
      
      Stuff$phi.mt = Stuff$phi.mt/n.iter
      
      return(Stuff)
    }
}

fn.mcmc <- function(true_parm, data, n.burn, n.reps, row.frac.probes, col.frac.probes, shuffle.indx.prob)
	{

	parm <- fn.init(data)
	init.parm <- parm

	parm = fn.subset(parm, row.frac.probes, col.frac.probes, entropy.prob=1)
	parm <- fn.iter(data, parm, row.frac.probes, col.frac.probes)
	
	parm = fn.workSmooth(tcgaFlag, storeFlag=FALSE, LSAFlag=FALSE, postLSAFlag=FALSE, text, text2="BURN = ", n.iter=n.burn,
	               parm2=parm, true_parm2=true_parm, row.frac.probes2=row.frac.probes, 
	               col.frac.probes2=col.frac.probes, 
	               shuffle.indx.prob2=shuffle.indx.prob, 
	               entropy.prob2=entropy.prob, 
	               meanRowFuzzy.mt=NULL, meanColFuzzy.mt=NULL)
	
	All.Stuff0 = fn.workSmooth(tcgaFlag, storeFlag=TRUE, LSAFlag=FALSE, postLSAFlag=FALSE, text, text2="REPS = ", n.iter=n.reps,
	                     parm2=parm, true_parm2=true_parm, row.frac.probes2=row.frac.probes, 
	                     col.frac.probes2=col.frac.probes, 
	                     shuffle.indx.prob2=shuffle.indx.prob, 
	                     entropy.prob2=entropy.prob, 
	                     meanRowFuzzy.mt=NULL, meanColFuzzy.mt=NULL)
	
	parm = All.Stuff0$parm                     
	
	All.Stuff1 = fn.workSmooth(tcgaFlag, storeFlag=TRUE, LSAFlag=TRUE, postLSAFlag=FALSE, text, text2="LSA = ", n.iter=n.reps/2,
	                     parm2=parm, true_parm2=true_parm, row.frac.probes2=row.frac.probes, 
	                     col.frac.probes2=col.frac.probes, 
	                     shuffle.indx.prob2=shuffle.indx.prob, 
	                     entropy.prob2=entropy.prob,
	                     meanRowFuzzy.mt=All.Stuff0$rowFuzzy.mt, meanColFuzzy.mt=All.Stuff0$colFuzzy.mt)
	
	parm = All.Stuff1$LSA_parm
	

	All.Stuff = fn.workSmooth(tcgaFlag, storeFlag=FALSE, LSAFlag=FALSE, postLSAFlag=TRUE, text, text2="post-LSA = ", n.iter=n.reps/2, 
	                     parm2=parm, true_parm2=true_parm, row.frac.probes2=row.frac.probes, 
	                     col.frac.probes2=col.frac.probes, 
	                     shuffle.indx.prob2=shuffle.indx.prob, 
	                     entropy.prob2=entropy.prob,
	                     meanRowFuzzy.mt=NULL, meanColFuzzy.mt=NULL)
	parm = All.Stuff$parm
	parm$clust$phi.mt = All.Stuff$phi.mt

	
	All.Stuff$G <- sum(All.Stuff$parm$clust$C.m.vec>0)
	All.Stuff$K <- sum(All.Stuff$parm$clust$n.vec>0)
	
	
	list(All.Stuff0, All.Stuff1, All.Stuff)
	
	}

