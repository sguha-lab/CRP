


fn.logLikMultinom <- function(parm, rowFlag)
{
  
  ## log.lik.mt: 
  # rows are SUBSETTED participants (rowFlag) or covariates(!rowFlag)
  # columns are the options for cliques (rowFlag) or clusters (!rowFlag)
  
  # pages 2-5 of 08/22/2023 notes
  
  if (rowFlag)
  {parm$subsettedWRow.ar = parm$WRow.ar[,,parm$rowUpdateIndx,]
  log.lik.mt = array(0,c(length(parm$rowUpdateIndx), parm$K.max))
  
  for (dd in 1:parm$A)
    for (xx in 1:parm$A)
    {log.lik.mt = log.lik.mt + parm$subsettedWRow.ar[dd,xx,,]*log(parm$clust$Q[dd,xx])
    }
  }
  
  if (!rowFlag)
  {parm$subsettedWcolumn.ar = parm$WColumn.ar[,,parm$colUpdateIndx,]
  log.lik.mt = array(0,c(length(parm$colUpdateIndx), parm$G.max))
  
  for (dd in 1:parm$A)
    for (xx in 1:parm$A)
    {log.lik.mt = log.lik.mt + parm$subsettedWcolumn.ar[dd,xx,,]*log(parm$clust$Q[dd,xx])
    }
  }
  
  #log.lik.v = colSums(log.lik.mt)
  parm$log.lik.mt = log.lik.mt
  
  parm
  
  
}



fn.clusterPostProbMultinom <- function(parm, rowFlag)
{
  
  parm = fn.logLikMultinom(parm, rowFlag)
  
  if (rowFlag)
  {log_prior.prob.v <- parm$log_p_r.v
  }
  
  if (!rowFlag)
  {log_prior.prob.v <- parm$log_p_c.v
  }
  
  # rows are SUBSETTED participants (rowFlag) or covariates(!rowFlag)
  # columns are the options for cliques (rowFlag) or clusters (!rowFlag)
  log_post.prob.mt = t(t(parm$log.lik.mt) + log_prior.prob.v)
  
  ###############
  ###############
  
  maxx.v <- apply(log_post.prob.mt, 1, max)    # HOT
  
  log_post.prob.mt <- log_post.prob.mt - maxx.v
  # apply(log_post.prob.mt, 1, max)
  
  post.prob.mt <- exp(log_post.prob.mt)
  # apply(post.prob.mt, 1, max)
  
  rowSums.v <- rowSums(post.prob.mt)
  post.prob.mt <- post.prob.mt/rowSums.v
  # apply(post.prob.mt, 1, sum)
  # summary(apply(post.prob.mt, 1, max))
  
  parm$clust$post.prob.mt <- post.prob.mt
  
  
  parm
}




fn.clusterGibbsMultinom <- function(parm, rowFlag)
{
  ###############
  
  err <- fn.qualityCheckMultinom(parm)
  if (err > 0)
  {stop(paste("GIBBS INITIAL: failed consistency check: err=",err))
  }
  
  # store just in case
  init.gibbs.parm <- parm
  
  ###############
  
  parm = fn.clusterPostProbMultinom(parm, rowFlag)
  
  parm$clust$label.v = fn.sample(parm$clust$post.prob.mt)
  
  parm
}


fn.row.gibbsMultinom <- function(parm)
{
  
  parm = fn.clusterGibbsMultinom(parm, rowFlag=TRUE)
  parm$clust$s.v[parm$rowUpdateIndx] = parm$clust$label.v
  parm = fn.clusterSummariesMultinom(parm, updateRows=TRUE, updateCols=FALSE)
  
  err <- fn.qualityCheckMultinom(parm)
  if (err > 0)
  {stop(paste("ROW GIBBS FINAL: failed consistency check: err=",err))
  }
  
  parm
}



fn.column.gibbsMultinom <- function(parm)
{
  
  parm = fn.clusterGibbsMultinom(parm, rowFlag=FALSE)
  parm$clust$c.v[parm$colUpdateIndx] = parm$clust$label.v
  parm = fn.clusterSummariesMultinom(parm, updateRows=FALSE, updateCols=TRUE)
  
  err <- fn.qualityCheckMultinom(parm)
  if (err > 0)
  {stop(paste("COLUMN GIBBS FINAL: failed consistency check: err=",err))
  }
  
  parm
}


fn.testMultinom <- function(parm, data_test_missing, true_parm_test)
{
  parm.test = parm
  
  parm.test$X = data_test_missing$X
  parm.test$n = data_test_missing$n
  
  # these n.test cases will be placed in the training sample
  # so parm.test$clust$phi.mt and parm.test$WRow.ar comes from All.Stuff
  # and the relevant dimensions are n.train (not n.test)
  
  # Further, index of rowUpdateIndx must be consistent with 
  # parm.test. In the general case where fullFlag=FALSE
  # test and training rows are disjoint, so parm.test$rowUpdateIndx
  # can't be chosen to be placed in training cases.
  # Also, summary stat parm$WRow.ar is of dimension 2 by 2 by n.train by parm$clust$K.max
  # So parm$WRow.ar cannot typically be subsetted for the test cases
  # They must be recomputed as below using fn.suffStatMultinom
  
  parm.test$rowUpdateIndx = 1:parm.test$n
  
  parm.test$WRow.ar =NULL
  parm.test = fn.suffStatMultinom(parm.test, rowFlag = TRUE, colFlag = FALSE, overRuleFlag=TRUE)
  
  parm.test = fn.clusterPostProbMultinom(parm=parm.test, rowFlag=TRUE)
  
  parm.test$clust$s.v = apply(parm.test$clust$post.prob.mt, 1, which.max)
  
  parm.test$mean.parity  <- fn.checkAccuracy(parm=parm.test, true_parm=true_parm_test, smoothFlag=FALSE)
  
  parm.test
}

