
source("preamble.R")

n = nrow(ALLstudy$Xstar)
n.burn=10000
n.reps=2.5*n.burn

source("main.R")
