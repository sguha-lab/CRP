fn.sample <- function(mat)
  {
    KG = ncol(mat)
    dd = nrow(mat)
    sample.v = array(,dd)
    
    for (cc in 1:dd)
      {sample.v[cc]=sample(1:KG,size=1,prob=mat[cc,])
      }
    
    sample.v
  }



fn.expandPhi <- function(parm, rowFlag)
{
  
  if (rowFlag)
  {
    parm$clust$expandedPhi.mt = array(,c(parm$K.max, parm$p))
    
    for (ss in 1:parm$K.max)
    {I.ss <- (parm$clust$s.v==ss)
    if (length(I.ss) > 0)
      {parm$clust$expandedPhi.mt[ss,] <- parm$clust$phi.mt[ss,parm$clust$c.v]
      }
    }
    
  }
    
  if (!rowFlag)
  {
      parm$clust$expandedPhi.mt = array(,c(parm$n, parm$G.max))
      
      for (gg in 1:parm$G.max)
      {I.gg <- (parm$clust$c.v==gg)
      if (length(I.gg) > 0)
        {parm$clust$expandedPhi.mt[,gg] <- parm$clust$phi.mt[parm$clust$s.v,gg]
        }
      }
  }
      
  parm
}


fn.log.lik <- function(parm, rowFlag)
{
  parm = fn.expandPhi(parm, rowFlag)

  if (rowFlag)
    {
    log.lik.mt = array(,c(length(parm$rowUpdateIndx), parm$K.max))
    
    for (cc in 1:length(parm$rowUpdateIndx))
      {i = parm$rowUpdateIndx[cc]
      col.i = !is.na(parm$X[i,])
      tmp.i = (t(parm$clust$expandedPhi.mt[,col.i]) - parm$X[i,col.i])
      log.lik.mt[cc,] = -.5*colSums(tmp.i^2)/parm$tau^2
      }
    }
  
  if (!rowFlag)
    {
      log.lik.mt = array(,c(length(parm$colUpdateIndx), parm$G.max))
      
      for (cc in 1:length(parm$colUpdateIndx))
        {j = parm$colUpdateIndx[cc]
        tmp.j = parm$clust$expandedPhi.mt - parm$X[,j]
        log.lik.mt[cc,] = -colSums(tmp.j^2)/2/parm$tau^2
        }
      
    }
  
  parm$log.lik.mt = log.lik.mt
  
  parm
  
 
}



fn.clusterPostProb <- function(parm, rowFlag)
{
  
  parm = fn.log.lik(parm, rowFlag)
  
  if (rowFlag)
     {log_prior.prob.v <- parm$log_p_r.v
     }
    
  if (!rowFlag)
    {log_prior.prob.v <- parm$log_p_c.v
    }
  
  log_post.prob.mt = t(t(parm$log.lik.mt) + log_prior.prob.v)

  maxx.v <- apply(log_post.prob.mt, 1, max)    
  
  log_post.prob.mt <- log_post.prob.mt - maxx.v
  
  post.prob.mt <- exp(log_post.prob.mt)
 
  rowSums.v <- rowSums(post.prob.mt)
  post.prob.mt <- post.prob.mt/rowSums.v

  parm$clust$post.prob.mt <- post.prob.mt

  
  parm
}




fn.clusterGibbs <- function(parm, rowFlag)
{
  parm = fn.clusterPostProb(parm, rowFlag)
  
  parm$clust$label.v = fn.sample(parm$clust$post.prob.mt)

  parm
}


fn.row.gibbs <- function(parm)
{

  parm = fn.clusterGibbs(parm, rowFlag=TRUE)
  parm$clust$s.v[parm$rowUpdateIndx] = parm$clust$label.v
  parm = fn.clusterSummariesSmooth(parm, updateRows=TRUE, updateCols=FALSE)
  
parm
}



fn.column.gibbs <- function(parm)
{
  
  parm = fn.clusterGibbs(parm, rowFlag=FALSE)
  parm$clust$c.v[parm$colUpdateIndx] = parm$clust$label.v
  parm = fn.clusterSummariesSmooth(parm, updateRows=FALSE, updateCols=TRUE)
  
  parm
}

